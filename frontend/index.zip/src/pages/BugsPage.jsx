import React, { useEffect, useState } from "react";
import axios from "axios";
import { API_URL } from "../config/config";
import { FaChevronDown, FaChevronUp } from "react-icons/fa";

function BugsPage() {
  const [tickets, setTickets] = useState([]);
  const [expandedTicket, setExpandedTicket] = useState(null);
  const [comments, setComments] = useState({});

  useEffect(() => {
    const fetchTickets = async () => {
      try {
        const token = localStorage.getItem("token");
        const response = await axios.get(`${API_URL}/tickets`, {
          headers: { Authorization: `Bearer ${token}` },
        });

        setTickets(response.data);
      } catch (error) {
        console.error("Error fetching tickets:", error);
      }
    };

    fetchTickets();
  }, []);

  const handleStatusChange = async (ticketId, newStatus) => {
    try {
      const token = localStorage.getItem("token");
      await axios.put(
        `${API_URL}/tickets/${ticketId}/updateStatus`,
        { status: newStatus },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      setTickets((prevTickets) =>
        prevTickets.map((ticket) =>
          ticket.id === ticketId ? { ...ticket, status: newStatus } : ticket
        )
      );
    } catch (error) {
      console.error("Error updating ticket status:", error);
    }
  };

  const toggleComments = async (ticketId) => {
    if (expandedTicket === ticketId) {
      setExpandedTicket(null);
      return;
    }

    try {
      const token = localStorage.getItem("token");
      const response = await axios.get(`${API_URL}/comments/${ticketId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      setComments((prev) => ({ ...prev, [ticketId]: response.data }));
      setExpandedTicket(ticketId);
    } catch (error) {
      console.error("Error fetching comments:", error);
    }
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Bugs Page</h1>
      <table className="min-w-full rounded-lg shadow-md" style={{ backgroundColor: "var(--card-bg)", color: "var(--text-primary)", border: "1px solid var(--border)" }}>
        <thead>
          <tr className="uppercase text-sm font-bold" style={{ backgroundColor: "var(--bg-primary)", color: "var(--text-primary)" }}>
            <td className="py-2 px-4 border-b">ID</td>
            <td className="py-2 px-4 border-b">Title</td>
            <td className="py-2 px-4 border-b">Description</td>
            <td className="py-2 px-4 border-b">Status</td>
            <td className="py-2 px-4 border-b">Severity</td>
            <td className="py-2 px-4 border-b">Expand Comments</td>
          </tr>
        </thead>
        <tbody>
          {tickets.map((ticket) => (
            <React.Fragment key={ticket.id}>
              <tr className="transition duration-300" style={{ backgroundColor: "var(--card-bg)" }}>
                <td className="py-2 px-4 border-b">{ticket.id}</td>
                <td className="py-2 px-4 border-b">{ticket.title}</td>
                <td className="py-2 px-4 border-b">{ticket.description}</td>

                <td className="py-2 px-4 border-b">
                  {ticket.status === "Closed" ? (
                    <span style={{ color: "var(--text-primary)" }}>Closed</span>
                  ) : (
                    <select
                      value={ticket.status}
                      onChange={(e) =>
                        handleStatusChange(ticket.id, e.target.value)
                      }
                      className="rounded-md px-2 py-1"
                      style={{ border: "1px solid var(--border)", backgroundColor: "var(--card-bg)", color: "var(--text-primary)" }}
                    >
                      <option value="Open">Open</option>
                      <option value="In Progress">In Progress</option>
                      <option value="Resolved">Resolved</option>
                      <option value="Closed">Closed</option>
                    </select>
                  )}
                </td>

                <td className="py-2 px-4 border-b">{ticket.severity}</td>

                {/* Arrow button for toggling comments */}
                <td className="py-2 px-4 border-b text-center">
                  <button
                    onClick={() => toggleComments(ticket.id)}
                    className="hover:opacity-80"
                    style={{ color: "var(--text-primary)" }}
                  >
                    {expandedTicket === ticket.id ? (
                      <FaChevronUp />
                    ) : (
                      <FaChevronDown />
                    )}
                  </button>
                </td>
              </tr>

              {/* Comments section (only visible if expanded) */}
              {expandedTicket === ticket.id && (
                <tr>
                  <td colSpan="6" className="p-4 border-t" style={{ backgroundColor: "var(--bg-primary)", borderColor: "var(--border)" }}>
                    <h2 className="text-lg font-semibold mb-3">Comments</h2>
                    {comments[ticket.id]?.length > 0 ? (
                      <ul className="space-y-4">
                        {comments[ticket.id].map((comment) => (
                          <li
                            key={comment.id}
                            className="p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300"
                            style={{ backgroundColor: "var(--card-bg)", border: "1px solid var(--border)", color: "var(--text-primary)" }}
                          >
                            <p className="text-sm" style={{ color: "var(--text-primary)" }}>
                              {comment.content}
                            </p>
                            {comment.fileUrl && (
                              <a
                                href={`http://localhost:8000${comment.fileUrl}`}
                                className="mt-2 inline-block text-blue-500 hover:underline"
                                target="_blank"
                                rel="noopener noreferrer"
                                download
                              >
                                Download File
                              </a>
                            )}
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p style={{ color: "var(--text-primary)" }}>No comments available.</p>
                    )}
                  </td>
                </tr>
              )}
            </React.Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default BugsPage;
