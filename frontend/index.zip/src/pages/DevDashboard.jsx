import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Logout from "../components/Logout";
import { API_URL } from "../config/config";

function DevDashboard({ setIsSignIn, setRoleId }) {
  const navigate = useNavigate();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newProject, setNewProject] = useState({
    title: "",
    description: "",
    startDate: "",
    endDate: "",
  });

  const handleCreateProject = async () => {
    const { title, description, endDate } = newProject;

    if (title && description && endDate) {
      try {
        const response = await axios.post(
          `${API_URL}/projects/createProject`,
          { title, description, endDate },
          {
            headers: {
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
          }
        );

        console.log("Project created successfully:", response.data);

        setNewProject({
          title: "",
          description: "",
          startDate: "",
          endDate: "",
        });
        setIsModalOpen(false);
      } catch (error) {
        console.error("Error creating project:", error);
        alert(
          "Couldn't create project: " +
            (error.response ? error.response.data.message : error.message)
        );
      }
    } else {
      alert("Fill in title, description, and end date first.");
    }
  };

  const tiles = [
    {
      eyebrow: "01 · NEW",
      title: "Create a project",
      body: "Spin up a new project and start tracking issues against it.",
      action: "New project",
      onClick: () => setIsModalOpen(true),
      rail: "#0F6B65",
    },
    {
      eyebrow: "02 · WORKSPACE",
      title: "Your projects",
      body: "Jump back into the projects you're assigned to.",
      action: "View projects",
      onClick: () => navigate("/projects"),
      rail: "#8B95A1",
    },
    {
      eyebrow: "03 · ASSIGNED",
      title: "Assigned bugs",
      body: "Bugs waiting on you, sorted by severity.",
      action: "View bugs",
      onClick: () => navigate("/bugs"),
      rail: "#C1521A",
    },
    {
      eyebrow: "04 · ACTIVITY",
      title: "Notifications",
      body: "Assignments, status changes, and new comments.",
      action: "View notifications",
      onClick: () => navigate("/notifications"),
      rail: "#D98C2B",
    },
  ];

  return (
    <div className="min-h-screen font-['Inter',sans-serif]" style={{ backgroundColor: 'var(--bg-primary)', color: 'var(--text-primary)' }}>
      {/* Top bar */}
      <div className="border-b" style={{ backgroundColor: 'var(--card-bg)', borderColor: 'var(--border)' }}>
        <div className="max-w-6xl mx-auto px-6 py-5 flex items-center justify-between">
          <div>
            <p className="font-['IBM_Plex_Mono',monospace] text-[11px] tracking-[0.14em] uppercase mb-1" style={{ color: 'var(--text-secondary)' }}>
              Workspace / Dashboard
            </p>
            <h1 className="font-['Space_Grotesk',sans-serif] text-2xl font-semibold tracking-tight">
              Developer dashboard
            </h1>
          </div>
          <Logout setIsSignIn={setIsSignIn} setRoleId={setRoleId} />
        </div>
      </div>

      {/* Tiles */}
      <div className="max-w-6xl mx-auto px-6 py-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {tiles.map((tile) => (
            <div
              key={tile.title}
              className="group rounded-md pl-5 pr-5 py-6 flex flex-col justify-between transition-all duration-150 hover:shadow-[0_8px_24px_-12px_rgba(18,22,28,0.18)] hover:-translate-y-0.5"
              style={{ backgroundColor: "var(--card-bg)", border: "1px solid var(--border)", color: "var(--text-primary)", borderLeft: `3px solid ${tile.rail}` }}
            >
              <div>
                    <p className="font-['IBM_Plex_Mono',monospace] text-[11px] tracking-[0.12em] uppercase mb-3" style={{ color: 'var(--text-secondary)' }}>
                  {tile.eyebrow}
                </p>
                <h2 className="font-['Space_Grotesk',sans-serif] text-lg font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>
                  {tile.title}
                </h2>
                <p className="text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                  {tile.body}
                </p>
              </div>
              <button
                onClick={tile.onClick}
                className="mt-6 self-start text-sm font-medium transition-colors flex items-center gap-1.5"
                style={{ color: 'var(--accent)' }}
              >
                {tile.action}
                <span aria-hidden="true" className="transition-transform group-hover:translate-x-0.5">
                  →
                </span>
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Create project modal */}
      {isModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center backdrop-blur-sm z-50 px-4" style={{ backgroundColor: 'var(--overlay)' }}>
          <div className="rounded-lg p-6 w-full max-w-md shadow-xl" style={{ backgroundColor: "var(--card-bg)", border: "1px solid var(--border)", color: "var(--text-primary)" }}>
            <p className="font-['IBM_Plex_Mono',monospace] text-[11px] tracking-[0.12em] uppercase mb-1" style={{ color: "var(--text-secondary)" }}>
              New project
            </p>
            <h2 className="font-['Space_Grotesk',sans-serif] text-xl font-semibold mb-5">
              Create project
            </h2>

            <label className="block text-xs font-medium mb-1.5" style={{ color: "var(--text-secondary)" }}>
              Title
            </label>
            <input
              type="text"
              placeholder="e.g. Checkout redesign"
              value={newProject.title}
              onChange={(e) =>
                setNewProject({ ...newProject, title: e.target.value })
              }
              className="rounded-md py-2 px-3 mb-4 w-full text-sm focus:outline-none"
              style={{ border: "1px solid var(--border)", backgroundColor: "var(--bg-primary)", color: "var(--text-primary)" }}
            />

            <label className="block text-xs font-medium mb-1.5" style={{ color: "var(--text-secondary)" }}>
              Description
            </label>
            <textarea
              placeholder="What's this project for?"
              value={newProject.description}
              onChange={(e) =>
                setNewProject({ ...newProject, description: e.target.value })
              }
              className="rounded-md py-2 px-3 mb-4 w-full text-sm focus:outline-none"
              style={{ border: "1px solid var(--border)", backgroundColor: "var(--bg-primary)", color: "var(--text-primary)" }}
              rows="3"
            />

            <label className="block text-xs font-medium mb-1.5" style={{ color: "var(--text-secondary)" }}>
              End date
            </label>
            <input
              type="date"
              value={newProject.endDate}
              onChange={(e) =>
                setNewProject({ ...newProject, endDate: e.target.value })
              }
              className="rounded-md py-2 px-3 mb-6 w-full text-sm focus:outline-none"
              style={{ border: '1px solid var(--border)', backgroundColor: 'var(--bg-primary)', color: 'var(--text-primary)' }}
            />

            <div className="flex justify-end gap-3">
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-sm font-medium py-2 px-4 rounded-md transition-colors"
                style={{ color: 'var(--text-secondary)' }}
              >
                Cancel
              </button>
              <button
                onClick={handleCreateProject}
                className="text-white text-sm font-medium py-2 px-4 rounded-md transition-colors"
                style={{ backgroundColor: 'var(--accent)' }}
              >
                Create project
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default DevDashboard;